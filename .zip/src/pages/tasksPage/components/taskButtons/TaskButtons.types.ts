export interface ITaskButtonProps {
  id: number;
  isCompleted: boolean;
  isImportant: boolean;
}
