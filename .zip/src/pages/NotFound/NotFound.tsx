export const NotFound = () => {
  return <h2>This page doesn&apos;t exist</h2>;
};
