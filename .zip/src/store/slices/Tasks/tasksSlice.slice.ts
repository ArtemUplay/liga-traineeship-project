import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { IInitialState } from './tasksSlice.types';
import { ISearchForm, ITask } from 'types/app';
import { FILTER } from 'constants/constants';

const initialState: IInitialState = {
  tasksArray: [],
  searchForm: {
    searchValue: '',
    filterType: FILTER.ALL,
  },
  isLoading: false,
  error: null,
};

export const tasksSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    setLoaderTasksPage: (state) => {
      state.isLoading = true;
    },
    unsetLoaderTasksPage: (state) => {
      state.isLoading = false;
    },
    setTasks: (state, action: PayloadAction<ITask[]>) => {
      state.tasksArray = action.payload.reverse();
    },
    updateTask: (state, action: PayloadAction<ITask>) => {
      const taskIndex = state.tasksArray.findIndex((task) => {
        return task.id === action.payload.id;
      });

      state.tasksArray[taskIndex] = { ...state.tasksArray[taskIndex], ...action.payload };
    },
    deleteTask: (state, action: PayloadAction<ITask['id']>) => {
      state.tasksArray = state.tasksArray.filter((task) => {
        return task.id !== action.payload;
      });
    },
    setSearchForm: (state, action: PayloadAction<ISearchForm>) => {
      state.searchForm = action.payload;
    },
    resetSearchForm: (state) => {
      state.searchForm = initialState.searchForm;
    },
  },
});

export const {
  setLoaderTasksPage,
  unsetLoaderTasksPage,
  setTasks,
  updateTask,
  deleteTask,
  setSearchForm,
  resetSearchForm,
} = tasksSlice.actions;
export const tasks = tasksSlice.reducer;
