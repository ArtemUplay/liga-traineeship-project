import { Paths } from 'constants/constants';

export interface ILinkComponentProps {
  path: Paths;
  text: string;
}
