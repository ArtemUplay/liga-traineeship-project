import { ReactNode } from 'react';

export interface PageContainerProps {
  children: ReactNode;
  className?: string;
}
